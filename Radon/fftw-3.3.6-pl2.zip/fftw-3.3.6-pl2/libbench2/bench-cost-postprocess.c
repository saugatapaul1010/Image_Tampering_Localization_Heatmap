/* not worth copyrighting */
#include "bench.h"

/* default routine, can be overridden by user */
double bench_cost_postprocess(double cost)
{
     return cost;
}
